-Step voltages with random duration to observe roller temperature response.
-Pyrometer cannot read anything below 50C and so until the temp. crosses that limit the temperature is read constant (3 mins at 1.5V).

-Actuation/Input: TOP PS : MAGNAPOWER TSD 10-6000
-State/Observation: Temp in C (Pyrometer)

- Max temp: 300C
- Max V: 5V
- RPM: 0.02
- Brush contact: 180 Phase
- Worked on single roller
  